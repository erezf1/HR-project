
import os
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from googleapiclient.http import MediaIoBaseDownload
import io

# Initialize the Google Drive API client
def authenticate():
    creds = Credentials.from_authorized_user_file('token.json')
    service = build('drive', 'v3', credentials=creds)
    return service

# List all files within the specified folder
def list_files(folder_id):
    service = authenticate()
    results = service.files().list(
        q=f"'{folder_id}' in parents and trashed=false",
        pageSize=10, 
        fields="nextPageToken, files(id, name, createdTime)").execute()
    items = results.get('files', [])
    if not items:
        print('No files found.')
    else:
        print('Files:')
        for item in items:
            print(u'{0} ({1})'.format(item['name'], item['id']))
    return items

# Download a file based on its ID
def download_file(file_id, file_name):
    service = authenticate()
    request = service.files().get_media(fileId=file_id)
    fh = io.BytesIO()
    downloader = MediaIoBaseDownload(fh, request)
    done = False
    while done is False:
        status, done = downloader.next_chunk()
        print("Download %d%%." % int(status.progress() * 100))
    fh.seek(0)
    
    with open(file_name, 'wb') as f:
        f.write(fh.read())
        f.close()

# Update a custom property or move the file to a different folder
def mark_file_as_processed(file_id, processed_folder_id):
    service = authenticate()
    # Move the file to the "processed" folder
    file = service.files().get(fileId=file_id,
                               fields='parents').execute()
    previous_parents = ",".join(file.get('parents'))
    # Move the file to the new folder
    file = service.files().update(fileId=file_id,
                                  addParents=processed_folder_id,
                                  removeParents=previous_parents,
                                  fields='id, parents').execute()
