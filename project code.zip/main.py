import google_drive_integration as gdi
import document_processing as dp
import openai_integration as openai
import data_storage_reporting_gdrive as dsr
import error_handling_notifications as ehn

# Configuration parameters (to be replaced with actual values)
GOOGLE_DRIVE_FOLDER_ID = "1_1PHDeB2pKSed28hFzP726wC9s38ggHg"
OPENAI_API_KEY = "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"
CSV_STORAGE_PATH = "csv_storage.csv"
EMAIL_RECIPIENTS = ["erez@mvp-house.com"]  # Notification recipients

#1 Create a folder 
#2 use proper folder id where you upload resumes 
#3 process and get results 

#4 I will create csv for response and uplod on drive

def main():
    try:
        # Authenticate with Google Drive and OpenAI API
        gdi.authenticate()
        openai.initialize_api(OPENAI_API_KEY)
        
        # List new resumes in the folder
        new_resumes = gdi.list_files(GOOGLE_DRIVE_FOLDER_ID)
        
        for resume in new_resumes:
            file_name = resume['name']  # Assuming you want to keep the original file name
            #local_file_path = "./downloads/{file_name}"  # Save files to a 'downloads' directory
            # This line is indented with four spaces relative to the function definition
            local_file_path = f"./downloads/{file_name}"
            # Further code to download the file would be at the same indentation level
            print(f"File will be saved to {local_file_path}")
            # Download the resume file
            gdi.download_file(resume['id'], local_file_path)
            # Download the resume file
            #file_path = gdi.download_file(resume['id'])
            
            # Extract and normalize text from the resume
            extracted_text = dp.extract_text(local_file_path)
            normalized_text = dp.normalize_text(extracted_text)
            
            # Define the list of questions for analysis
            questions = "What are the key skills mentioned?" 
            
            # Send analysis request to OpenAI and parse the response
            combined_string = normalized_text + "\n" + questions
            #print (combined_string)
            analysis_response = openai.send_analysis_request( combined_string)
            print("analytics respose::", analysis_response)
            #parsed_response = openai.parse_api_response(analysis_response)
            
            # Record the analysis results in the CSV file
            dsr.write_to_csv({
                'file_name': resume['name'],
                'submission_date': resume['createdTime'],
                'gpt_analytics': analysis_response
            }, CSV_STORAGE_PATH)
            
            # Mark the file as processed in Google Drive
            gdi.mark_file_as_processed(resume['id'])
            
        # Optional: Generate a report after processing all resumes
        dsr.generate_report("2023-01-01", "2023-01-31")  # Example date range
        
    except Exception as e:
        # Log the error and notify administrators
        ehn.log_error({'message': str(e)})
        # this is the place to send email error
        #ehn.send_notification(f"Error processing resumes: {str(e)}", EMAIL_RECIPIENTS)

if __name__ == "__main__":
    main()
